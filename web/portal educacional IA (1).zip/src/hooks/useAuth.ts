import { useState, useEffect, useCallback } from 'react';
import { User } from '@/lib/index';

const STORAGE_KEY = 'dcz_edu_auth_v1_2026';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const restoreSession = () => {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        try {
          const parsed = JSON.parse(stored) as User;
          if (parsed && parsed.email && parsed.isAuthenticated) {
            setUser(parsed);
          }
        } catch {
          localStorage.removeItem(STORAGE_KEY);
        }
      }
      setIsLoading(false);
    };

    restoreSession();
  }, []);

  const sendOTP = useCallback(async (email: string): Promise<boolean> => {
    try {
      // Preparado para integração Supabase Auth:
      // await supabase.auth.signInWithOtp({ email })
      
      console.info(`[Auth 2026] Solicitando OTP para: ${email}`);
      await new Promise((resolve) => setTimeout(resolve, 800));
      return true;
    } catch (error) {
      console.error('Erro ao enviar código:', error);
      return false;
    }
  }, []);

  const login = useCallback(async (email: string, code: string): Promise<boolean> => {
    try {
      // Preparado para integração Supabase Auth:
      // const { data, error } = await supabase.auth.verifyOtp({ email, token: code, type: 'email' })
      
      await new Promise((resolve) => setTimeout(resolve, 1000));

      if (code.length === 6) {
        const sessionUser: User = {
          email,
          isAuthenticated: true,
        };
        
        setUser(sessionUser);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(sessionUser));
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Erro na autenticação:', error);
      return false;
    }
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem(STORAGE_KEY);
    window.location.reload();
  }, []);

  return {
    user,
    isLoading,
    isAuthenticated: !!user?.isAuthenticated,
    sendOTP,
    login,
    logout,
  };
}