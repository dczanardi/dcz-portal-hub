import React from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import {
  BookOpen,
  FileText,
  Atom,
  FlaskConical,
  Dna,
  Library,
  Globe,
  Languages,
  PenTool,
  GraduationCap,
  ArrowUpRight
} from "lucide-react";
import { AIAgent, AIAgentIcon, ROUTE_PATHS } from "@/lib/index";
import { useAuth } from "@/hooks/useAuth";
import { IMAGES } from "@/assets/images";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";

/**
 * DCZ Pensando Educação - Agent Card Component
 * 
 * @description Displays an AI agent with an icon, name, and description.
 * Handles navigation and authentication logic for accessing agents.
 * @year 2026
 */

interface AgentCardProps {
  agent: AIAgent;
}

const IconMap: Record<AIAgentIcon, React.ComponentType<{ className?: string }>> = {
  BookOpen,
  FileText,
  Atom,
  FlaskConical,
  Dna,
  Library,
  Globe,
  Languages,
  PenTool,
  GraduationCap,
};

const getAgentData = (agentId: string) => {
  const agentMap: Record<string, { image: string; color: string; category: string }> = {
    'ai-ebook': { 
      image: IMAGES.DIGITAL_EBOOK_20260214_221842_62, 
      color: 'bg-blue-500', 
      category: 'Tecnologia Educacional' 
    },
    'ai-redacao': { 
      image: IMAGES.ESSAY_CORRECTION_20260214_221842_61, 
      color: 'bg-red-500', 
      category: 'Linguagens' 
    },
    'ai-fisica': { 
      image: IMAGES.PHYSICS_INCLINED_PLANE_20260214_221844_54, 
      color: 'bg-blue-600', 
      category: 'Ciências Exatas' 
    },
    'ai-quimica': { 
      image: IMAGES.CHEMISTRY_MOLECULES_20260214_221842_56, 
      color: 'bg-green-500', 
      category: 'Ciências da Natureza' 
    },
    'ai-biologia': { 
      image: IMAGES.DNA_HELIX_BIOLOGY_20260214_221843_55, 
      color: 'bg-emerald-500', 
      category: 'Ciências da Natureza' 
    },
    'ai-historia': { 
      image: IMAGES.HISTORY_TIMELINE_20260214_221842_57, 
      color: 'bg-amber-600', 
      category: 'Ciências Humanas' 
    },
    'ai-geografia': { 
      image: IMAGES.GEOGRAPHY_WORLD_MAP_20260214_221844_58, 
      color: 'bg-teal-500', 
      category: 'Ciências Humanas' 
    },
    'ai-portugues': { 
      image: IMAGES.PORTUGUESE_GRAMMAR_20260214_221843_59, 
      color: 'bg-purple-500', 
      category: 'Linguagens' 
    },
    'ai-english-writing': { 
      image: IMAGES.ENGLISH_WRITING_ICON_20260214_221310_50, 
      color: 'bg-indigo-500', 
      category: 'Linguagens' 
    },
    'ai-english-learning': { 
      image: IMAGES.ENGLISH_CONVERSATION_20260214_221842_60, 
      color: 'bg-cyan-500', 
      category: 'Linguagens' 
    }
  };
  
  return agentMap[agentId] || { 
    image: IMAGES.AI_EDUCATION_2, 
    color: 'bg-primary', 
    category: 'Educação' 
  };
};

export function AgentCard({ agent }: AgentCardProps) {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const agentData = getAgentData(agent.id);

  const handleAccess = () => {
    if (agent.requiresLogin && !isAuthenticated) {
      // Redirect to login, storing current path to return after successful OTP
      navigate(ROUTE_PATHS.LOGIN, { 
        state: { 
          from: window.location.pathname, 
          target: agent.url 
        } 
      });
    } else {
      // Open the external agent link
      window.open(agent.url, "_blank", "noopener,noreferrer");
    }
  };

  return (
    <motion.div
      whileHover={{ y: -8, scale: 1.02 }}
      transition={{ type: "spring", stiffness: 300, damping: 25 }}
      className="h-full"
    >
      <div className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden h-full flex flex-col">
        {/* Image Section - Takes up half the card */}
        <div className="relative h-48 overflow-hidden">
          <img 
            src={agentData.image} 
            alt={`Ilustração ${agent.name}`}
            className="w-full h-full object-cover"
          />
          {/* Category Tag */}
          <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-medium text-gray-700">
            {agentData.category}
          </div>
          {/* Brand Icon */}
          <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm w-8 h-8 rounded-lg flex items-center justify-center">
            <span className="text-xs font-bold text-gray-700">DCZ</span>
          </div>
        </div>

        {/* Content Section */}
        <div className="p-6 flex-grow flex flex-col">
          {/* Title with colored dot */}
          <div className="flex items-start gap-3 mb-3">
            <div className={`w-3 h-3 rounded-full ${agentData.color} mt-1.5 flex-shrink-0`}></div>
            <h3 className="text-lg font-bold text-gray-900 leading-tight">
              {agent.name}
            </h3>
          </div>

          {/* Description */}
          <p className="text-gray-600 text-sm leading-relaxed mb-6 flex-grow">
            {agent.description}
          </p>

          {/* Action Button */}
          <button
            onClick={handleAccess}
            className={`w-full ${agentData.color} text-white font-semibold py-3 px-4 rounded-xl hover:opacity-90 transition-all duration-200 flex items-center justify-center gap-2 group shadow-lg`}
          >
            <span className="text-sm">✨</span>
            Acessar Tutor IA
            <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
