import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Mail, ShieldCheck, ChevronLeft, Loader2, ArrowRight } from 'lucide-react';
import { ROUTE_PATHS } from '@/lib/index';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from '@/components/ui/input-otp';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { springPresets, fadeInUp } from '@/lib/motion';

/**
 * Login Page - DCZ Pensando Educação
 * 
 * @description Implements an OTP (One-Time Password) login flow with two steps:
 * 1. Email collection
 * 2. 6-digit verification code
 */
export default function Login() {
  const { login, sendOTP, isAuthenticated, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [step, setStep] = useState<'email' | 'otp'>('email');
  const [email, setEmail] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated && !authLoading) {
      const from = location.state?.from?.pathname || ROUTE_PATHS.HOME;
      navigate(from, { replace: true });
    }
  }, [isAuthenticated, authLoading, navigate, location]);

  const handleSendOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsSubmitting(true);
    setError(null);

    const success = await sendOTP(email);
    if (success) {
      setStep('otp');
    } else {
      setError('Ocorreu um erro ao enviar o código. Tente novamente.');
    }
    setIsSubmitting(false);
  };

  const handleVerifyOTP = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (otpCode.length !== 6) return;

    setIsSubmitting(true);
    setError(null);

    const success = await login(email, otpCode);
    if (success) {
      const from = location.state?.from?.pathname || ROUTE_PATHS.HOME;
      navigate(from, { replace: true });
    } else {
      setError('Código inválido ou expirado. Verifique e tente novamente.');
    }
    setIsSubmitting(false);
  };

  // Auto-submit when 6 digits are reached
  useEffect(() => {
    if (otpCode.length === 6 && step === 'otp') {
      handleVerifyOTP();
    }
  }, [otpCode, step]);

  return (
    <div className="min-h-[calc(100vh-140px)] flex items-center justify-center px-4 py-12">
      <div className="absolute inset-0 z-0 opacity-5 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,var(--primary)_0%,transparent_70%)]" />
      </div>

      <motion.div
        initial="initial"
        animate="animate"
        variants={fadeInUp}
        transition={springPresets.gentle}
        className="w-full max-w-md z-10"
      >
        <Card className="border-border/50 shadow-xl backdrop-blur-sm bg-card/95">
          <CardHeader className="space-y-1 text-center">
            <div className="mx-auto bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
              {step === 'email' ? (
                <Mail className="text-primary w-6 h-6" />
              ) : (
                <ShieldCheck className="text-primary w-6 h-6" />
              )}
            </div>
            <CardTitle className="text-2xl font-bold tracking-tight">
              {step === 'email' ? 'Acessar o Hub' : 'Verificar Identidade'}
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              {step === 'email'
                ? 'Digite seu e-mail para receber um código de acesso.'
                : `Enviamos um código de 6 dígitos para ${email}`}
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-4">
            <AnimatePresence mode="wait">
              {step === 'email' ? (
                <motion.form
                  key="email-step"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  onSubmit={handleSendOTP}
                  className="space-y-4"
                >
                  <div className="space-y-2">
                    <Label htmlFor="email">E-mail institucional ou pessoal</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="seu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="bg-background/50"
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full font-medium h-11"
                    disabled={isSubmitting || !email}
                  >
                    {isSubmitting ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <>
                        Receber código
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                </motion.form>
              ) : (
                <motion.form
                  key="otp-step"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  onSubmit={handleVerifyOTP}
                  className="space-y-6 flex flex-col items-center"
                >
                  <div className="space-y-3 w-full">
                    <Label className="text-center block">Código de Verificação</Label>
                    <div className="flex justify-center">
                      <InputOTP
                        maxLength={6}
                        value={otpCode}
                        onChange={setOtpCode}
                        autoFocus
                        disabled={isSubmitting}
                      >
                        <InputOTPGroup className="gap-2">
                          <InputOTPSlot index={0} className="w-10 h-12 sm:w-12 sm:h-14 text-lg" />
                          <InputOTPSlot index={1} className="w-10 h-12 sm:w-12 sm:h-14 text-lg" />
                          <InputOTPSlot index={2} className="w-10 h-12 sm:w-12 sm:h-14 text-lg" />
                          <InputOTPSlot index={3} className="w-10 h-12 sm:w-12 sm:h-14 text-lg" />
                          <InputOTPSlot index={4} className="w-10 h-12 sm:w-12 sm:h-14 text-lg" />
                          <InputOTPSlot index={5} className="w-10 h-12 sm:w-12 sm:h-14 text-lg" />
                        </InputOTPGroup>
                      </InputOTP>
                    </div>
                  </div>
                  <Button
                    type="submit"
                    className="w-full font-medium h-11"
                    disabled={isSubmitting || otpCode.length < 6}
                  >
                    {isSubmitting ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      'Confirmar e Entrar'
                    )}
                  </Button>
                </motion.form>
              )}
            </AnimatePresence>

            {error && (
              <Alert variant="destructive" className="mt-4 py-2">
                <AlertDescription className="text-xs">{error}</AlertDescription>
              </Alert>
            )}
          </CardContent>

          <CardFooter className="flex flex-col space-y-4 pt-2">
            {step === 'otp' && (
              <Button
                variant="ghost"
                size="sm"
                className="text-muted-foreground hover:text-primary transition-colors"
                onClick={() => setStep('email')}
                disabled={isSubmitting}
              >
                <ChevronLeft className="mr-2 h-4 w-4" />
                Alterar e-mail
              </Button>
            )}
            <p className="text-xs text-center text-muted-foreground px-4">
              Ao continuar, você concorda com nossos termos de uso e política de privacidade. 
              © 2026 DCZ Pensando Educação.
            </p>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
}
